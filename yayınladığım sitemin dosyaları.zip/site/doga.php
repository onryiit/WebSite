<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w3.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>DOĞA  <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">DOĞA </h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section">
  <div class="container">
    <div class="row d-flex">
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/a1.jpg" class="block-20 img" style="background-image: url('images/a1.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2017</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/a2.jpeg" class="block-20 img" style="background-image: url('images/a2.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2018</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/a3.jpeg" class="block-20 img" style="background-image: url('images/a3.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2018</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/a4.jpg" class="block-20 img" style="background-image: url('images/a4.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/a5.jpg" class="block-20 img" style="background-image: url('images/a5.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/a6.jpg" class="block-20 img" style="background-image: url('images/a6.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>






</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>