<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w3.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>UÇAN ZONGULDAKLI  <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">UÇAN ZONGULDAKLI </h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section">
  <div class="container">
    <div class="row d-flex">
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/u1.jpg" class="block-20 img" style="background-image: url('images/u1.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">25 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/u2.jpg" class="block-20 img" style="background-image: url('images/u2.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">25 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/u3.jpg" class="block-20 img" style="background-image: url('images/u3.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/u10.jpeg" class="block-20 img" style="background-image: url('images/u10.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/u11.jpeg" class="block-20 img" style="background-image: url('images/u11.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/u12.jpg" class="block-20 img" style="background-image: url('images/u12.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 TEMMUZ 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>


<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/u13.jpg" class="block-20 img" style="background-image: url('images/u13.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">6 TEMMUZ 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>





</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>