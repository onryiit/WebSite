<object width="1900" height="2400" type="application/pdf" data="/cv.pdf" id="pdf_content">
<p>Pdf dokümanı yüklenemedi..</p>
</object>
