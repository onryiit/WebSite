<?php include 'header.php' ?>

	<section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w5.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-end">
				<div class="col-md-9 ftco-animate pb-5 mb-5">
					<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>PROJELERİM <i class="fa fa-chevron-right"></i></span></p>
					<h1 class="mb-3 bread">PROJELERİM</h1>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section ftco-portfolio">
		<div class="row justify-content-center no-gutters">
			<div class="col-md-12 heading-section text-center ftco-animate mb-5">
				<h2 class="mb-2"></h2>
			</div>
		</div>

		<div class="container">
			<div class="row no-gutters pb-5">
				<div class="col-md-12 portfolio-wrap mt-0">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 img" style="background-image: url(images/site.png);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-0 pl-lg-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
											<span class="subheading"></span>
											<h2 class="mb-2"><a href="work.html">İNTERNET SİTEM</a></h2>
										</div>
										<div class="absolute">
											<p>Şu anda bulunmuş olduğunuz siteyi şahsi olarak yaptım sitenin template dosyasını internetten alıp üstündeki tüm değişiklerini kendim yaptım arka plandaki kodlama işlemleri ve düzenleme kendime aittir.Normalde web programlaması veya web tasarımı okuduğum bölüm bize gösterilmesede şu an da bulunduğumuz pandemi döneminde kenimi geliştirmek amacıyla web hakkında kendimi geliştirmeye çalışıyorum.</p>
											<div class="icon d-flex align-items-center mb-4">
												<div class="img" style="background-image: url(images/m3.jpg);"></div>
												<div class="position pl-3">
													<h4 class="mb-0">ONUR YİĞİT</h4>
													<span></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 order-md-last img" style="background-image: url(images/database.jpg);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pr-md-5 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc text-md-right">
										<div class="top">
											<span class="subheading"></span>
											<h2 class="mb-2"><a href="work.html">VERİ ANALİZİ</a></h2>
										</div>
										<div class="absolute">
											<p>Şu anda Muğla Sıtkı Koçman Üniversitesi Bilgisayar Mühendisliği bölümünde okumaktayım ve okulda 1 tane database projesinde çalışma fırsatı buldum.Ve büyük bir veri için mysql üzerinden ben ve diğer iki arkadaşım ile birlikte veri analizi yaptık</p>
											<div class="d-flex w-100">
												<div class="icon d-flex align-items-center ml-md-auto mb-4">
													<div class="img" style="background-image: url(images/m3.jpg);"></div>
													<div class="position pl-3 text-left">
														<h4 class="mb-0">ONUR YİĞİT</h4>
														<span></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row mt-5 py-md-5">
				<div class="col text-center">
					<div class="block-27">
					</div>
				</div>
			</div>
		</div>
	</section>

	<?php include 'footer.php' ?>
		
	</body>
	</html>