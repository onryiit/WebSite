<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w3.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>MUĞLADA 3 YIL  <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">MUĞLADA 3 YIL </h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section">
  <div class="container">
    <div class="row d-flex">
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/3.jpg"  class="block-20 img" style="background-image: url('images/3.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">25 Ekim 2018</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/10.jpeg" class="block-20 img" style="background-image: url('images/10.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">16 Aralık 2018</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/11.jpeg" class="block-20 img" style="background-image: url('images/11.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 Mart 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/12.jpeg" class="block-20 img" style="background-image: url('images/12.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">29 mayıs 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
   <div class="blog-entry justify-content-end">
    <div class="text">
     <h3 class="heading mb-3"><a href="#"></a></h3>
     <a href="images/5.jpg" class="block-20 img" style="background-image: url('images/5.jpg');">
     </a>
     <div class="meta mb-3">
      <div><a href="#">20 Aralık 2019</a></div>
      <div><a href="#"></a></div>
    </div>
    <p></p>
  </div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/2.jpeg" class="block-20 img" style="background-image: url('images/2.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">20 Aralık 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/13.jpeg" class="block-20 img" style="background-image: url('images/13.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">1 HAZİRAN 2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
       <div class="blog-entry justify-content-end">
        <div class="text">
         <h3 class="heading mb-3"><a href="muglada3yıl.php"></a></h3>
         <a href="images/1.jpg'" class="block-20 img" style="background-image: url('images/1.jpg');">
         </a>
         <div class="meta mb-3">
          <div><a href="#">24 Şubat 2020</a></div>
          <div><a href="#"></a></div>
        </div>
        <p></p>
      </div>
    </div>
  </div>

</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>