
	</section>		
	<footer class="ftco-footer ftco-section">
		<div class="container">
			<div class="row mb-5">
				<div class="col-md">
					<div class="ftco-footer-widget mb-4">
						<a class="navbar-brand" href="index.php"><span>ONR</span>YİİT</a>
						<p>"Gençken yanınızda olmasına ihtiyaç duyduğunuz birine dönüşün."</p>
						<ul class="ftco-footer-social list-unstyled mt-5">
							<li class="ftco-animate"><a href="https://twitter.com/onryiit"><span class="fa fa-twitter"></span></a></li>
							<li class="ftco-animate"><a href="https://www.facebook.com/onryiit"><span class="fa fa-facebook"></span></a></li>
							<li class="ftco-animate"><a href="https://www.instagram.com/onryiit/?hl=tr"><span class="fa fa-instagram"></span></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md">
					<div class="ftco-footer-widget mb-4 ml-md-4">
						<h2 class="ftco-heading-2">Topluluk</h2>
						<ul class="list-unstyled">
							<li><a href="projelerim.php"><span class="fa fa-chevron-right mr-2"></span>Projelerim</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md">
					<div class="ftco-footer-widget mb-4 ml-md-4">
						<h2 class="ftco-heading-2">HAKKIMDA</h2>
						<ul class="list-unstyled">
							<li><a href="hakkımda.php"><span class="fa fa-chevron-right mr-2"></span>Hikayem</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md">
					<div class="ftco-footer-widget mb-4">
						<h2 class="ftco-heading-2">Sorularınız için.</h2>
						<div class="block-23 mb-3">
							<ul>
								<li><span class="icon fa fa-map"></span><span class="text">Yeni Mahalle Tokulluoğlu Sokak So:7 Daire:10 Çaycuma/Zonguldak</span></li>
								<li><a href="iletişim.php"><span class="icon fa fa-phone"></span><span class="text">05388551368</span></a></li>
								<li><a href="iletişim.php"><span class="icon fa fa-envelope pr-4"></span><span class="text">onryiit@gmail.com</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			</div>
		</footer>
		
		

		<!-- loader -->
		<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-migrate-3.0.1.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script src="js/jquery.waypoints.min.js"></script>
		<script src="js/jquery.stellar.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/jquery.animateNumber.min.js"></script>
		<script src="js/scrollax.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
		<script src="js/google-map.js"></script>
		<script src="js/main.js"></script>