<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w3.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>Blog <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">Blog</h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section">
  <div class="container">
    <div class="row d-flex">
      <div class="col-md-3 d-flex ftco-animate">
       <div class="blog-entry justify-content-end">
        <div class="text">
         <h3 class="heading mb-3"><a href="#">MUĞLADA 3 YIL</a></h3>
         <a href="muglada3yıl.php" class="block-20 img" style="background-image: url('images/1.jpg');">
         </a>
         <div class="meta mb-3">
          <div><a href="#">2018-2020</a></div>
          <div><a href="#">ONUR YİĞİT</a></div>
        </div>
        <p>Bu albümde 2018"den 2020"ye kadar muğlada yakaladığım güzel anları sizlerler paylaşmak istedim.</p>
      </div>
    </div>
  </div>
  <div class="col-md-3 d-flex ftco-animate">
   <div class="blog-entry justify-content-end">
    <div class="text">
     <h3 class="heading mb-3"><a href="#">UÇAN ZONGULDAKLI</a></h3>
     <a href="ucanzonguldaklı.php" class="block-20 img" style="background-image: url('images/u1.jpg');">
     </a>
     <div class="meta mb-3">
      <div><a href="#">2019</a></div>
      <div><a href="#">ONUR YİĞİT</a></div>
    </div>
    <p>Bu albümde çok sevdiğim gökyüzünün içinden çektiğim fotoğrafları sizlerle paylaşmak istedim.</p>
  </div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#">DOĞA</a></h3>
   <a href="doga.php" class="block-20 img" style="background-image: url('images/a1.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2017-2020</a></div>
    <div><a href="#">ONUR YİĞİT</a></div>
  </div>
  <p>Bu albümde en sevdiğim şehir olan İstanbuldan ve memleketim Zonguldaktan bazı fotoğraflar bulunmakta. </p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#">ANILAR</a></h3>
   <a href="anılar.php" class="block-20 img" style="background-image: url('images/m2.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2017-2020</a></div>
    <div><a href="#"></a></div>
  </div>
  <p>Bu albüm  üniversitenin bana kazandırdığı güzel insanlar ile yaşadığım güzel anların bazılarını içerir.  </p>
</div>
</div>
</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>