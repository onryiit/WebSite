<?php include 'header.php' ?>

	<section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w1.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-end">
				<div class="col-md-9 ftco-animate pb-5 mb-5">
					<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa<i class="fa fa-chevron-right"></i></a></span> <span>Hakkımda <i class="fa fa-chevron-right"></i></span></p>
					<h1 class="mb-3 bread">Hakkımda</h1>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center no-gutters">
				<div class="col-md-12 heading-section text-center ftco-animate mb-5">
					<h2 class="mb-2">Hakkımda</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-vector"></span></div>
						<div class="media-body py-md-4">
							<h3>Python</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-web-programming"></span></div>
						<div class="media-body py-md-4">
							<h3>Java</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-layer"></span></div>
						<div class="media-body py-md-4">
							<h3>Html</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-coding"></span></div>
						<div class="media-body py-md-4">
							<h3>Mysql</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-zoom"></span></div>
						<div class="media-body py-md-4">
							<h3>PHP</h3>
						</div>
					</div>      
				</div>
			</div>
			<div class="row wrap-about py-5">
				<div class="col-md-8">
					<div class="row">
						<div class="col-md-6 order-md-last ftco-animate d-flex">
							<div class="img w-100" style="background-image: url(images/about.jpg);"></div>
						</div>
						<div class="col-md-6 ftco-animate">
							<div class="text text-md-right">
								<h3>Özgeçmişim</h3>
								<p>Kısaca kendimi tanıtayım. 12.02.1998 yılında Zonguldak'ta doğdum.İlköğretim ve liseyi Zonguldak'ın Çaycuma ilçesinde tamamladım.Şu an Muğla Sıtkı Koçman Üniversitesi Bilgisayar Mühendisliği üçüncü sınıf öğrencisiyim.</p>
								<a href="cv.pdf"target="_blank">Özgeçmişimi görmek için tıklayın..</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="text">
						<p>Bu siteyi kendimi geliştirmek,web ve web tasarımında üzerinde bilgiye sahip olmak , Yeni programlama dillerini öğrenmek için yaptım.Öncelikli hedefim buydu. Ancak bunlarında dışında sitemin içerisinde kendi hayatımdan vloglar ve kendi hakkımda bir çok bilgiye ulaşabilirsiniz. Yukarıda gördüğünüz programlama dilleri şu ana kadar öğrendiğim programlama dilleridir.</p>
						
					</div>
				</div>
			</div>
			<h1>HEDEFLERİM</h1>
			<div class="row pt-5">
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>01</span>
						<div class="text">
							<h3>YÜKSEK LİSANS YAPMAK</h3>
							<p>Öncelikli hedefim üniversiteyi bitirdikten sonra yüksek lisans yapmak. Bunu istememin sebebi ise okuduğum bölümü seviyorum bu bölümü kendi isteğim doğrultusunda seçmiştim ve gayet mutluyum kodlama yapmayı bu alanda kendimi geliştirmeyi seviyorum bu yüzden öncelikli hedefim yüksek lisans yapmak.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>02</span>
						<div class="text">
							<h3>İyi Bir Mühendis Olmak</h3>
							<p>Açıkcası bunun için çabalıyorum kendimi bir şekilde geliştirmeye çalışıyorum. Yeni diller öğrenmeye çalışıyorum.Şu an için staj arayan bir bilgisayar mühendisi adayıyım. Eğer kendimi  geliştirebileceğim aynı zamanda projeler yapabiliceğim bir şirkette iyi bir staj yapabilirsem bu projeleri büyük mutlulukla ilerletebileceğimi düşünüyorum. Bu gibi çalışmalar sayesinde de iyi tecrübeler kazanabileceğime inanıyorum. </p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>03</span>
						<div class="text">
							<h3>Kazandğım bilgileri Paylaşmak</h3>
							<p>Kendimi geliştirmekten kastım aslında tek bir konu üstünde değildi yani sadece programla üstünde kendimi geliştirmekten bahsetmiyorum. Bir çok alanda kendimi geliştirmeye çalışıyorum hayattan kazandığım tecrübeler inişler çıkışlar okul hayatım çevrem arkadaşlarım hepsi benim için bir tecrübedir. İlerideki hayatımda bu kazandığım tecrübeleri başklarına aktarmayı çok isterim</p>
						</div>
					</div>
				</div>
			</div>

			<div class="row pt-5">
				<div class="col-md-12">
					<div class="intro p-md-4 py-md-5 p-2 rounded img" style="background-image: url(images/bg_1.jpg);">
						<div class="col-md-6 ftco-animate">
							<span> <strong>Şimdi size okuduğum okul hakkında kısa bilgi vereyim.</strong></span>
							<h2>MUĞLA SITKI KOÇMAN ÜNİVERSİTESİ</h2>
							<p><a href="mühendislik.php" class="btn btn-primary">MSKÜ Mühendislik Fakültesi hakkında bilgi almak için tıklayınız...</a></p>
						</div>
						<div class="col-md-6 ftco-animate">
							<p><a href="ceng.php" class="btn btn-primary">MSKÜ Bilgisyar Mühendisliği hakkında bilgi almak için tıklayınız...</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section bg-light">
		<div class="container">
			<div class="row justify-content-center no-gutters">
				<div class="col-md-12 heading-section text-center ftco-animate mb-5">
					<h2 class="mb-2">SİTE SAHİBİ</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-3 ftco-animate">
					<div class="staff">
						<div class="img-wrap d-flex align-items-stretch justify-content-end">
							<div class="img align-self-stretch" style="background-image: url(images/foto1.jpeg);">
								<ul class="ftco-social">
									<li class="ftco-animate d-flex"><a href="https://twitter.com/onryiit" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate d-flex"><a href="https://www.facebook.com/onryiit" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate d-flex"><a href="https://www.instagram.com/onryiit/" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
						<div class="text d-flex align-items-center pt-3">
							<div class="desc">
								<h3 class="mb-2">ONUR <br>YİĞİT</h3>
								<span class="position mb-4">BİLGİSAYAR MÜHENDİSLİĞİ ÖĞRENCİSİ</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	

	<?php include 'footer.php' ?>
		
	</body>
	</html>