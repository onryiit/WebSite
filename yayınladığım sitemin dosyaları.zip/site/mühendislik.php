<?php include 'header.php' ?>

	<section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/wallpaper.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-end">
				<div class="col-md-9 ftco-animate pb-5 mb-5">
					<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>MSKÜ MÜHENDİSLİK FAKÜLTESİ<i class="fa fa-chevron-right"></i></span></p>
					<h1 class="mb-3 bread">MSKÜ MÜHENDİSLİK FAKÜLTESİ</h1>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section ftco-portfolio">
		<div class="row justify-content-center no-gutters">
			<div class="col-md-12 heading-section text-center ftco-animate mb-5">
				<h2 class="mb-2">TARİHÇE</h2>
			</div>
		</div>

		<div class="container">
			<div class="row no-gutters pb-5">
				<div class="col-md-12 portfolio-wrap mt-0">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 img" style="background-image: url(images/ceng1.jpg);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-0 pl-lg-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
										</div>
										<div class="absolute">
											<p>Fakültemiz, 2809 sayılı kanunun ek 30. maddesi uyarınca Bakanlar Kurulu'nun 18/04/2001 tarih ve 2001/2351 sayılı kararı ile kurulması uygun görülerek 22/05/2001 tarih ve 24409 sayılı Resmi Gazete'de yayımlanması ile tüzel kişilik kazanmıştır. Fakültemiz bünyesinde; İnşaat Mühendisliği, Jeoloji Mühendisliği, Maden Mühendisliği, Elektrik-Elektronik Mühendisliği, Bilgisayar Mühendisliği, Endüstri Mühendisliği, Metalürji ve Malzeme Mühendisliği, Makine Mühendisliği olmak üzere 8 bölümün kurulması; Yükseköğretim Kurulu Başkanlığı Yürütme Kurulunun 18/3/2002 tarihli toplantısında 2547 sayılı Yükseköğretim Kanunun 7/d-2 maddesi uyarınca uygun görülmüş, yine aynı kurulun 16/4/2002 tarihli toplantısında bölüm adlarını taşıyan anabilim dallarının kurulması da uygun görülmüştür.</p>
											<div class="icon d-flex align-items-center mb-4">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 order-md-last img" style="background-image: url(images/mühendislik2.jpg);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pr-md-5 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc text-md-right">
										<div class="top">
											<h2> MİSYON</h2>
										</div>
										<div class="absolute">
											<p>
                  							Çağın gereklerine uygun, yenilikçi ve evrensel nitelikte eğitim vermek. Üniversiteyi ve bilgi toplumunu ileriye taşıyacak niteliklere sahip araştırmacılar yetiştirmek. Ülke ihtiyaçları doğrultusunda, mevcut duruma ve olabilecek gelişmelere çabuk uyum sağlayabilecek, teknik donanımlı mezunlar vermek.Uluslararası bilimsel platformlarda üniversitemizi ve ülkemizi temsil etmek.Gerek duyulan konularda, ulusal ve bölgesel sorunların çözümü için fikir üretmek ve bilimsel düşüncenin toplum içinde gelişmesi için kamuoyu oluşturmak  
              								</p>
											<div class="d-flex w-100">
												<div class="icon d-flex align-items-center ml-md-auto mb-4">
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 img" style="background-image: url(images/mühendislik3.png);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-md-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
											<h2>VİZYON</h2>
										</div>
										<div class="absolute">
											<p><blockquote>
                							Mühendislik Fakültesinin yurtiçi ve yurtdışındaki mühendislik fakülteleri ile bilimsel işbirliğine öncelik veren, araştırma ve eğitim etkinliklerinde diğer üniversiteler ile işbirliği yapan, bu amacı için yabancı dili üst düzeyde kullanma becerisine sahip ve teknolojik gelişmeleri takip edebilen öğrencilerin yetişmelerinde eğitim, araştırma ve geliştirme etkinliklerinin kalitesine öncelik veren bilim insanları önderliğinde evrensel hizmet sunabilen, öğrencilerin bu gelişimini tamamlayabilmeleri için dikey bir büyüme modeli benimseyerek, hem mühendislik konularının bilim dünyasında kabul gören tüm evrensel değerlerine sahip hem de bulunduğu coğrafyanın karakteristik yapısının kendisine sağladığı farklı konulardaki bilimsel tecrübe ve birikimini arttırarak mühendislik fakülteleri arasında kendine özgü bir yere sahip olmaktır.
              								</blockquote></p>
											<div class="icon d-flex align-items-center mb-4">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				
		


		</div>
	</section>

	<?php include 'footer.php' ?>
		
	</body>
	</html>