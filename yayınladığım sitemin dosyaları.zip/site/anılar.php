<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w3.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>ANILAR <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">ANILAR </h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section">
  <div class="container">
    <div class="row d-flex">
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/m1.jpg" class="block-20 img" style="background-image: url('images/m1.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/m2.jpg" class="block-20 img" style="background-image: url('images/m2.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/m3.jpeg" class="block-20 img" style="background-image: url('images/m3.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></a></h3>
   <a href="images/m4.jpeg" class="block-20 img" style="background-image: url('images/m4.jpeg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/m5.jpg" class="block-20 img" style="background-image: url('images/m5.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>
<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/m7.jpg" class="block-20 img" style="background-image: url('images/m7.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>

<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/m8.jpg" class="block-20 img" style="background-image: url('images/m8.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>



<div class="col-md-3 d-flex ftco-animate">
 <div class="blog-entry justify-content-end">
  <div class="text">
   <h3 class="heading mb-3"><a href="#"></h3>
   <a href="images/m6.jpg" class="block-20 img" style="background-image: url('images/m6.jpg');">
   </a>
   <div class="meta mb-3">
    <div><a href="#">2019</a></div>
    <div><a href="#"></a></div>
  </div>
  <p></p>
</div>
</div>
</div>






</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>