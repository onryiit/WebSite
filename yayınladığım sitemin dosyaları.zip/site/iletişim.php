<?php include 'header.php' ?>

 <section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/w4.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end">
      <div class="col-md-9 ftco-animate pb-5 mb-5">
       <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>İletişim <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-3 bread">İLETİŞİM</h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section contact-section ftco-no-pb" id="contact-section">
  <div class="container">
   <div class="row justify-content-center mb-5 pb-3">
    <div class="col-md-7 heading-section text-center ftco-animate">
      <span class="subheading"> ONUR YİĞİT</span>
      <h2 class="mb-4">İLETİŞİM BİLGİLERİ</h2>
      <p></p>
    </div>
  </div>

  <div class="row block-9">
    <div class="col-md-8">
     
  
</div>

<div class="col-md-12">
 <div class="row">
   <div class="dbox w-100 d-flex ftco-animate">
    <div class="icon d-flex align-items-center justify-content-center">
     <span class="fa fa-map-marker"></span>
   </div>
   <div class="text">
     <p><span>Adres:</span> <strong>Yeni Mahalle Tokulluoğlu Sokak So:7 Daire:10 Çaycuma/Zonguldak</strong></p>
   </div>
 </div>
 <div class="dbox w-100 d-flex ftco-animate">
  <div class="icon d-flex align-items-center justify-content-center">
   <span class="fa fa-phone"></span>
 </div>
 <div class="text">
   <p><span>Telefon Numarası:</span> <a href="tel://05388551368">05388551368</a></p>
 </div>
</div>
<div class="dbox w-100 d-flex ftco-animate">
  <div class="icon d-flex align-items-center justify-content-center">
   <span class="fa fa-paper-plane"></span>
 </div>
 <div class="text">
   <p><span>Email:</span> <a href="#">onryiit@gmail.com</a></p>
 </div>
</div>
<div class="dbox w-100 d-flex ftco-animate">
  <div class="icon d-flex align-items-center justify-content-center">
   <span class="fa fa-globe"></span>
 </div>
 <div class="text">
   <p><span>LinkedIn:</span> <a href="https://www.linkedin.com/in/onur-yi%C4%9Fit-b210bb19a/" target="_blank">LinkedIn Onur Yiğit</a></p>
 </div>
</div>
</div>
</div>
</div>
</div>
</section>	

<?php include 'footer.php' ?>

</body>
</html>