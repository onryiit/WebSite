<?php include 'header.php' ?>
	<meta charset="utf-8">
	<section class="hero-wrap degree-right js-fullheight">
		<div class="home-slider js-fullheight owl-carousel">
			<div class="slider-item js-fullheight" style="background-image:url(images/bg_1.jpg);">
				<div class="overlay"></div>
				<div class="container">
					<div class="row no-gutters slider-text js-fullheight align-items-center">
						<div class="col-md-12 ftco-animate">
							<div class="absolute">
								<h4 class="number" data-number="3">0</h4>
								<p>Şu ana kadar 3 tane projem var. </p>
							</div>
							<div class="text">
								<h1 class="mb-4">HOŞGELDİNİZ.</h1>
								<p>Sevdiğim sözlerden birisi : "Gençken yanınızda olmasına ihtiyaç duyduğunuz birine dönüşün."</p>
							</div>
						</div>
						<a href="video.php" class="img-video popup-vimeo d-flex align-items-center justify-content-center">
							<span class="fa fa-play"></span>
						</a>
					</div>
				</div>
			</div>

			<div class="slider-item js-fullheight" style="background-image:url(images/wallpaper.jpg);">
				<div class="overlay"></div>
				<div class="container">
					<div class="row no-gutters slider-text js-fullheight align-items-center">
						<div class="col-md-12 ftco-animate">
							
								
							</div>
							<div class="text">
								<h1 class="mb-4">BU SİTE BENİM HAKKIMDAKİ BİLGİLERİ İÇERİR.</h1>
								<p>Felsefem : Yapmış olduğun şeylerin üstünde, bir şey yapmadıkça büyüyemezsin. <strong>"Andre Gide"</strong></p>
							</div>
						</div>
						<a href="https://vimeo.com/45830194" class="img-video popup-vimeo d-flex align-items-center justify-content-center">
							<span class="fa fa-play"></span>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center no-gutters">
				<div class="col-md-12 heading-section text-center ftco-animate mb-5">
					<h2 class="mb-2">Hakkımda</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-vector"></span></div>
						<div class="media-body py-md-4">
							<h3>Python</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-web-programming"></span></div>
						<div class="media-body py-md-4">
							<h3>Java</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-layer"></span></div>
						<div class="media-body py-md-4">
							<h3>Html</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-coding"></span></div>
						<div class="media-body py-md-4">
							<h3>Mysql</h3>
						</div>
					</div>      
				</div>
				<div class="col-md d-flex align-items-stretch ftco-animate">
					<div class="media block-6 w-100 services d-block text-center">
						<div class="icon d-flex justify-content-center align-items-center"><span class="flaticon-zoom"></span></div>
						<div class="media-body py-md-4">
							<h3>PHP</h3>
						</div>
					</div>      
				</div>
			</div>
			<div class="row wrap-about py-5">
				<div class="col-md-8">
					<div class="row">
						<div class="col-md-6 order-md-last ftco-animate d-flex">
							<div class="img w-100" style="background-image: url(images/about.jpg);"></div>
						</div>
						<div class="col-md-6 ftco-animate">
							<div class="text text-md-right">
								<h3>Özgeçmişim</h3>
								<p>Kısaca kendimi tanıtayım. 12.02.1998 yılında Zonguldak'ta doğdum.İlköğretim ve liseyi Zonguldak'ın Çaycuma ilçesinde tamamladım.Şu an Muğla Sıtkı Koçman Üniversitesi Bilgisayar Mühendisliği üçüncü sınıf öğrencisiyim.</p>
								<a href="cv.pdf "target="_blank"> <strong>Özgeçmişimi görmek için tıklayın... </strong></a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="text">
						<p>Bu siteyi kendimi geliştirmek,web ve web tasarımında üzerinde bilgiye sahip olmak , Yeni programlama dillerini öğrenmek için yaptım.Öncelikli hedefim buydu. Ancak bunlarında dışında sitemin içerisinde kendi hayatımdan vloglar ve kendi hakkımda bir çok bilgiye ulaşabilirsiniz. Yukarıda gördüğünüz programlama dilleri şu ana kadar öğrendiğim programlama dilleridir.</p>
						
					</div>
				</div>
			</div>
			<h1>HEDEFLERİM</h1>
			<div class="row pt-5">
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>01</span>
						<div class="text">
							<h3>YÜKSEK LİSANS YAPMAK</h3>
							<p>Öncelikli hedefim üniversiteyi bitirdikten sonra yüksek lisans yapmak. Bunu istememin sebebi ise okuduğum bölümü seviyorum bu bölümü kendi isteğim doğrultusunda seçtim ve gayet mutluyum.Kodlama yapmayı bu alanda kendimi geliştirmeyi seviyorum bu yüzden öncelikli hedefim yüksek lisans yapmak.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>02</span>
						<div class="text">
							<h3>İyi Bir Mühendis Olmak</h3>
							<p>Açıkcası bunun için çabalıyorum kendimi bir şekilde geliştirmeye çalışıyorum. Yeni diller öğrenmeye çalışıyorum.Şu an için staj arayan bir bilgisayar mühendisi adayıyım. Eğer kendimi  geliştirebileceğim aynı zamanda projeler yapabiliceğim bir şirkette iyi bir staj yapabilirsem bu projeleri büyük mutlulukla ilerletebileceğimi düşünüyorum. Bu gibi çalışmalar sayesinde de iyi tecrübeler kazanabileceğime inanıyorum. </p>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="services-2 d-flex ftco-animate">
						<span>03</span>
						<div class="text">
							<h3>Kazandığım bilgileri Paylaşmak</h3>
							<p>Kendimi geliştirmekten kastım aslında tek bir konu üstünde değildi yani sadece programla üstünde kendimi geliştirmekten bahsetmiyorum. Bir çok alanda kendimi geliştirmeye çalışıyorum hayattan kazandığım tecrübeler inişler çıkışlar okul hayatım çevrem arkadaşlarım hepsi benim için bir tecrübedir. İlerideki hayatımda bu kazandığım tecrübeleri başkalarına aktarmayı çok isterim</p>
						</div>
					</div>
				</div>
			</div>


	</section>

	<section class="ftco-section ftco-portfolio bg-light">
		<div class="row justify-content-center no-gutters">
			<div class="col-md-12 heading-section text-center ftco-animate mb-5">
				<h2 class="mb-2">PROJELERİM</h2>
			</div>
		</div>

		<div class="container">
			<div class="row no-gutters">
				<div class="col-md-12 portfolio-wrap mt-0">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 img" style="background-image: url(images/site.png);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-0 pl-lg-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
											<span class="subheading"></span>
											<h2 class="mb-2"><a href="work.html">İNTERNET SİTEM</a></h2>
										</div>
										<div class="absolute">
											<p>Şu anda bulunmuş olduğunuz siteyi şahsi olarak yaptım sitenin template dosyasını internetten alıp üstündeki tüm değişiklerini kendim yaptım arka plandaki kodlama işlemleri ve düzenleme kendime aittir.Normalde web programlaması ve web tasarımı okuduğum bölümde bize gösterilmese de şu an da bulunduğumuz pandemi döneminde kendimi geliştirmek amacıyla web hakkında kendimi geliştirmeye çalışıyorum.</p>
											<div class="icon d-flex align-items-center mb-4">
												<div class="img" style="background-image: url(images/m3.jpg);"></div>
												<div class="position pl-3">
													<h4 class="mb-0">ONUR YİĞİT</h4>
													<span></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 order-md-last img" style="background-image: url(images/database.jpg);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pr-md-5 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc text-md-right">
										<div class="top">
											<span class="subheading"></span>
											<h2 class="mb-2"><a href="work.html">VERİ ANALİZİ</a></h2>
										</div>
										<div class="absolute">
											<p>Şu anda Muğla Sıtkı Koçman Üniversitesi Bilgisayar Mühendisliği bölümünde okumaktayım ve okulda 1 tane database projesinde çalışma fırsatı buldum.Ve büyük bir veri için mysql üzerinden ben ve diğer iki arkadaşım ile birlikte veri tabanı oluşturduk.</p>
											<div class="d-flex w-100">
												<div class="icon d-flex align-items-center ml-md-auto mb-4">
													<div class="img" style="background-image: url(images/m3.jpg);"></div>
													<div class="position pl-3 text-left">
														<h4 class="mb-0">ONUR YİĞİT</h4>
														<span></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>




	<section class="ftco-section bg-light">
		<div class="container">
			<div class="row justify-content-center mb-5">
				<div class="col-md-7 heading-section text-center ftco-animate">
					<h2>Blog</h2>
				</div>
			</div>
			<div class="row d-flex">
				<div class="col-md-3 d-flex ftco-animate">
					<div class="blog-entry justify-content-end">
						<div class="text">
							<h3 class="heading mb-3"><a href="blog.php">MUĞLADA 3 YIL</a></h3>
							<a href="blog.php" class="block-20 img" style="background-image: url('images/1.jpg');">
							</a>
							<div class="meta mb-3">
								<div><a href="blog.php">2018-2020</a></div>
								<div><a href="blog.php">ONUR YİĞİT</a></div>
							</div>
							<p>Bu albümde 2018"den 2020"ye kadar muğlada yakaladığım güzel anları sizlerler paylaşmak istedim.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 d-flex ftco-animate">
					<div class="blog-entry justify-content-end">
						<div class="text">
							<h3 class="heading mb-3"><a href="blog.php">UÇAN ZONGULDAKLI</a></h3>
							<a href="blog.php" class="block-20 img" style="background-image: url('images/u1.jpg');">
							</a>
							<div class="meta mb-3">
								<div><a href="blog.php">2019</a></div>
								<div><a href="blog.php">ONUR YİĞİT</a></div>
							</div>
							<p>Bu albümde çok sevdiğim gökyüzünün içinden çektiğim fotoğrafları sizlerle paylaşmak istedim.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 d-flex ftco-animate">
					<div class="blog-entry justify-content-end">
						<div class="text">
							<h3 class="heading mb-3"><a href="blog.php">DOĞA</a></h3>
							<a href="blog.php" class="block-20 img" style="background-image: url('images/a1.jpg');">
							</a>
							<div class="meta mb-3">
								<div><a href="blog.php">2017-2020</a></div>
								<div><a href="blog.php">ONUR YİĞİT</a></div>
							</div>
							<p>Bu albümde en sevdiğim şehir olan İstanbuldan ve memleketim Zonguldaktan bazı fotoğraflar bulunmakta.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 d-flex ftco-animate">
					<div class="blog-entry justify-content-end">
						<div class="text">
							<h3 class="heading mb-3"><a href="blog.php">ANILAR</a></h3>
							<a href="blog.php" class="block-20 img" style="background-image: url('images/m2.jpg');">
							</a>
							<div class="meta mb-3">
								<div><a href="blog.php">2017-2020</a></div>
								<div><a href="blog.php"></a></div>
							</div>
							<p>Bu albüm  üniversitenin bana kazandırdığı güzel insanlar ile yaşadığım güzel anların bazılarını içerir.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="degree-right-footer"></div>
	</section>		

<?php include 'footer.php' ?>
		
	</body>
	</html>