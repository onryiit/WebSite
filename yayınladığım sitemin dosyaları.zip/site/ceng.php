<?php include 'header.php' ?>

	<section class="hero-wrap hero-wrap-2 degree-right" style="background-image: url('images/wallpaper.jpg');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-end">
				<div class="col-md-9 ftco-animate pb-5 mb-5">
					<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Anasayfa <i class="fa fa-chevron-right"></i></a></span> <span>MSKÜ BİLGİSAYAR MÜHENDİSLİĞİ<i class="fa fa-chevron-right"></i></span></p>
					<h1 class="mb-3 bread">MSKÜ BİLGİSAYAR MÜHENDİSLİĞİ</h1>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section ftco-portfolio">
		<div class="row justify-content-center no-gutters">
			<div class="col-md-12 heading-section text-center ftco-animate mb-5">
				<h2 class="mb-2">HAKKIMIZDA</h2>
			</div>
		</div>

		<div class="container">
			<div class="row no-gutters pb-5">
				<div class="col-md-12 portfolio-wrap mt-0">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 img" style="background-image: url(images/ceng1.jpg);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-0 pl-lg-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
										</div>
										<div class="absolute">
											<p>Bölümümüz 2009-2010 eğitim-öğretim yılında öğrenci almaya başlamış ve ilk mezunlarını 2013-2014 eğitim-öğretim yılının sonunda vermiştir.</p>
											<div class="icon d-flex align-items-center mb-4">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">
						<div class="col-md-5 order-md-last img" style="background-image: url(images/mühendislik3.png);">
							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pr-md-5 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc text-md-right">
										<div class="top">
											<br>
											<h2> EĞİTİM</h2>
										</div>
										<div class="absolute">
											Bölümümüzde eğitim %100 İngilizcedir. Programa kabul edilen öğrenciler yabancı dil yeterliliğini sağlamıyorsa 1 yıl yabancı dil hazırlık eğitimi alırlar. Bölümümüzde 40 iş günü zorunlu staj vardır. 3. Sınıftan itibaren müfredatın çoğunluğunu bölüm içi ve bölüm dışı seçmeli dersler oluşturmakta, böylece öğrencilerimiz Bilgisayar Mühendisliğinin farklı alanlarında özelleşmeye ve mühendislik dışı alanlarda bilgi sahibi olmaya özendirilmektedir. Derslerde kullanılan programlar özgür yazılımdır, öğrencilerimiz bu felsefeyi benimseyerek mezun olmaktadır. Teknik derslerde verilen çok sayıda ödev ve proje ile mezunlarımızın hem teorik hem uygulama yönlerinin güçlü olması hedeflenmektedir.
 
              								2019-2020 eğitim öğretim yılı itibari ile bölümümüzde 10 doktoralı öğretim üyesi ders vermektedir. Bölüm kontenjanımız ise 70’tir.
 
              								Bölümümüz mezunları lisans programından mezun olduktan sonra, Biyoinformatik alanında Yüksek Lisans ve Doktora programlarına devam edebilmektedir.
											<div class="d-flex w-100">
												<div class="icon d-flex align-items-center ml-md-auto mb-4">
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12 portfolio-wrap">
					<div class="row no-gutters align-items-center">							
						</div>
						<div class="col-md-7">
							<div class="text pt-5 pl-md-5 pl-md-4 ftco-animate">
								<div class="px-4 px-lg-4">
									<div class="desc">
										<div class="top">
											<br>
											<br>
											<h2>TANITIM VİDEOSU</h2>
											<iframe width="560" height="315" src="https://www.youtube.com/embed/8QRLGAljRsM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>
										<div class="absolute">
											
											<div class="icon d-flex align-items-center mb-4">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				
		


		</div>
	</section>

	<?php include 'footer.php' ?>
		
	</body>
	</html>