<?php 
$borsa = file_get_contents("https://www.borsadirekt.com/");
preg_match_all('@<div class="col-md-2 col-xs-6 li (.*?)">(.*?)</div>@si , $borsa, $dolar');
print_r($dolar[0][1]);
 ?>